﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Cavalli.Zaghini
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Partita p = new Partita();
        public MainWindow()
        {
            InitializeComponent();
            p = new Partita();
            p.Vittoria();
        }
        public void Blocca()
        {
            btn0.IsEnabled = false;
            btn1.IsEnabled = false;
            btn2.IsEnabled = false;
            btn3.IsEnabled = false;
            btn4.IsEnabled = false;
            btn5.IsEnabled = false;
            btn6.IsEnabled = false;
            btn7.IsEnabled = false;
            btn8.IsEnabled = false;
        }
        private void Button_Click_0(object sender, RoutedEventArgs e)
        {
            p.Mossa(0, 0);
            btn0.Content = p.campo[0, 0].libera;
            p.Vittoria();
            if (p.Vittoria() != " ")
            {
                MessageBox.Show(p.Vittoria());
                Blocca();
            }
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            p.Mossa(0, 1);
            btn1.Content = p.campo[0, 1].libera;
            p.Vittoria();
            if (p.Vittoria() != " ")
            {
                MessageBox.Show(p.Vittoria());
                Blocca();
            }
        }
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            p.Mossa(0, 2);
            btn2.Content = p.campo[0, 2].libera;
            p.Vittoria();
            if (p.Vittoria() != " ")
            {
                MessageBox.Show(p.Vittoria());
                Blocca();
            }
        }
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            p.Mossa(1, 0);
            btn2.Content = p.campo[1, 0].libera;
            p.Vittoria();
            if (p.Vittoria() != " ")
            {
                MessageBox.Show(p.Vittoria());
                Blocca();
            }

        }
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            p.Mossa(1, 1);
            btn2.Content = p.campo[1, 1].libera;
            p.Vittoria();
            if (p.Vittoria() != " ")
            {
                MessageBox.Show(p.Vittoria());
                Blocca();
            }
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            p.Mossa(1, 2);
            btn2.Content = p.campo[1, 2].libera;
            p.Vittoria();
            if (p.Vittoria() != " ")
            {
                MessageBox.Show(p.Vittoria());
                Blocca();
            }
        }
        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            p.Mossa(2, 0);
            btn2.Content = p.campo[2, 0].libera;
            p.Vittoria();
            if (p.Vittoria() != " ")
            {
                MessageBox.Show(p.Vittoria());
                Blocca();
            }
        }
        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            p.Mossa(2, 1);
            btn2.Content = p.campo[2, 1].libera;
            p.Vittoria();
            if (p.Vittoria() != " ")
            {
                MessageBox.Show(p.Vittoria());
                Blocca();
            }
        }
        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            p.Mossa(2, 2);
            btn2.Content = p.campo[2, 2].libera;
            p.Vittoria();
            if (p.Vittoria() != " ")
            {
                MessageBox.Show(p.Vittoria());
                Blocca();
            }
        }
    }
}