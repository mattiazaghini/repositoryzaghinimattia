﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cavalli.Zaghini
{
    public class Partita
    {
        public bool turno { get; set; }
        public Cella[,] campo = new Cella[3, 3];
        public string Risultato { get; set; }

        public Partita()
        {
            for (int r = 0; r < 3; r++)
            {
                for (int c = 0; c < 3; c++)
                {
                    campo[r, c] = new Cella(r, c);
                }
                turno = true;
                Risultato = " ";
            }
        }
        public void Mossa(int _r, int _c)
        {
            if (campo[_r, _c].libera == " ")
            {
                if (turno == true)
                {
                    campo[_r, _c].Occupata("X");
                    turno = false;
                }
                else
                {
                    campo[_r, _c].Occupata("O");
                    turno = true;
                }
            }
        }

        public string Vittoria()
        {

            if (campo[0, 0].libera + campo[0, 1].libera + campo[0, 2].libera == "XXX" || campo[1, 0].libera + campo[1, 1].libera + campo[1, 2].libera == "XXX" || campo[2, 0].libera + campo[2, 1].libera + campo[2, 2].libera == "XXX") //righe g1
            {
                Risultato = "Il giocatore 1 ha vinto";
            }
            else if (campo[0, 0].libera + campo[1, 0].libera + campo[2, 0].libera == "XXX" || campo[0, 1].libera + campo[1, 1].libera + campo[2, 1].libera == "XXX" || campo[0, 2].libera + campo[1, 2].libera + campo[2, 2].libera == "XXX") //colonne g1
            {
                Risultato = "Il giocatore 1 ha vinto";
            }
            else if (campo[0, 0].libera + campo[1, 1].libera + campo[2, 2].libera == "XXX" || campo[0, 2].libera + campo[1, 1].libera + campo[2, 0].libera == "XXX") //diagonali g1
            {
                Risultato = "Il giocatore 1 ha vinto";
            }
            else if (campo[0, 0].libera + campo[0, 1].libera + campo[0, 2].libera == "OOO" || campo[1, 0].libera + campo[1, 1].libera + campo[1, 2].libera == "OOO" || campo[2, 0].libera + campo[2, 1].libera + campo[2, 2].libera  == "OOO") //righe g2
            {
                Risultato = "Il giocatore 2 ha vinto";
            }
            else if (campo[0, 0].libera + campo[1, 0].libera + campo[2, 0].libera == "OOO" || campo[0, 1].libera + campo[1, 1].libera + campo[2, 1].libera == "OOO" || campo[0, 2].libera + campo[1, 2].libera  + campo[2, 2].libera == "OOO") //colonne g2
            {
                Risultato = "Il giocatore 2 ha vinto";
            }
            else if (campo[0, 0].libera + campo[1, 1].libera + campo[2, 2].libera == "OOO" || campo[0, 2].libera + campo[1, 1].libera + campo[2, 0].libera == "OOO") //diagonali g2
            {
                Risultato = "Il giocatore 2 ha vinto";
            }

            return Risultato;
        }
    }
    public class Cella
    {
  
        public string libera { get; set; }
        public int riga { get; set; }
        public int colonna { get; set; }
       
        public Cella()
        {
            throw new Exception();
        }
        public Cella(int r, int c)
        {
            riga = r;
            colonna = c;
            libera = " ";
        }
        public void Occupata(string s)
        {
            libera = s;
        }
        
    }
}
