function premi(){
	alert("prova");
}
function premiVincente(){
	//alert("Bravo sono il bottone vincente");
	creaVincitore();
}
function premiPerdente(){
	alert("Hai perso");
}


function creaVincitore(){
	//togliamo vincente
 var win=document.getElementsByClassName('vincente');
 if (win.length==1){
	 win[0].classList.remove("vincente");
 }
var bottoni=document.getElementsByClassName('bottone');

for(let i=0;i<bottoni.length;i++){
	bottoni[i].addEventListener('click',premiPerdente);
	}
	
	var index=Math.floor(Math.random()*bottoni.length);
	
	bottoni[index].classList.add("vincente");
	bottoni[index].removeEventListener('click',premiPerdente);
	bottoni[index].addEventListener('click',premiVincente);
}
creaVincitore();